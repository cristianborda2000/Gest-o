# ZAMA Admin

Sistema administrativo da ZAMA.

Esta versao esta separada em HTML, CSS, JavaScript e Tailwind para facilitar
manutencao futura.

## Mapa rapido do projeto

```text
outputs/zama-tailwind/
  index.html                  Tela principal e estrutura base
  zama-logo.png               Logo usado no sistema e no contrato
  assets/styles.input.css     CSS de origem, edite este arquivo
  assets/styles.css           CSS compilado pelo Tailwind
  assets/js/config.js         Modulos, campos dos formularios e dados iniciais
  assets/js/core.js           Estado, localStorage, troca de telas e indicadores
  assets/js/forms.js          Formularios dinamicos e abas internas
  assets/js/dashboard.js      Dashboard, resumos e graficos
  assets/js/contracts.js      Contrato/PDF de clientes
  assets/js/table.js          Tabelas, calendario e botoes de acao
  assets/js/records.js        Regras de negocio, financeiro, agenda e utilitarios
  assets/js/boot.js           Inicializacao e eventos globais
```

## Onde mexer

- Para mudar campos de cadastro: edite `assets/js/config.js`.
- Para mudar cores, layout e responsividade: edite `assets/styles.input.css`.
- Para mudar o dashboard: edite `assets/js/dashboard.js`.
- Para mudar o contrato/PDF: edite `assets/js/contracts.js`.
- Para mudar calendario, tabelas ou botoes de acao: edite `assets/js/table.js`.
- Para mudar regras automaticas de financeiro, projetos, mensalidades ou agenda: edite `assets/js/records.js`.
- Para mudar botoes globais como importar/exportar/limpar: edite `assets/js/boot.js`.

## Como os dados sao salvos

Os dados ficam no navegador usando `localStorage`, com a chave definida em
`assets/js/config.js`:

```js
const storageKey = "admin-simples-v1";
```

Isso significa que os dados nao ficam dentro dos arquivos do projeto. Para levar
dados de uma versao para outra, use os botoes `Exportar dados` e `Importar dados`.

## Logica principal

- Projetos geram duas entradas financeiras automaticamente: 50% no inicio e 50% na conclusao.
- Mensalidades pagas geram entrada financeira.
- Clientes ativos criam/atualizam mensalidades automaticamente.
- Gastos fixos e vencimentos financeiros aparecem na agenda.
- Itens concluidos da agenda aparecem em verde no calendario.

## Ordem dos scripts

O `index.html` carrega os arquivos JS nesta ordem:

```text
config.js -> core.js -> forms.js -> dashboard.js -> contracts.js -> table.js -> records.js -> boot.js
```

Essa ordem e importante porque os arquivos compartilham funcoes e variaveis
globais. Se criar um arquivo novo, coloque-o antes de `boot.js`.

## Instalar dependencias

Se o comando `npm` nao for reconhecido, instale primeiro o Node.js LTS pelo site oficial:

```text
https://nodejs.org/en/download
```

Durante a instalacao, mantenha marcada a opcao de adicionar o Node.js ao PATH.
Depois feche e abra novamente o terminal.

Para conferir se instalou corretamente:

```bash
node -v
npm -v
```

Depois rode na raiz do projeto:

```bash
npm.cmd install
```

## Compilar Tailwind

```bash
npm.cmd run build:css
```

## Rodar localmente

```bash
npm.cmd run serve
```

O arquivo principal desta versao e:

```text
outputs/zama-tailwind/index.html
```

## Levar dados da versao antiga

Os dados ficam salvos no navegador pelo `localStorage`. Quando o sistema muda de
link, pasta ou servidor, o navegador pode nao carregar os dados antigos
automaticamente.

Para migrar:

1. Abra a versao antiga.
2. Clique em `Exportar dados`.
3. Abra esta versao nova.
4. Clique em `Importar dados`.
5. Selecione o arquivo `.json` exportado.
